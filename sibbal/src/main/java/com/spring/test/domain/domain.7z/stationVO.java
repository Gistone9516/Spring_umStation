package com.spring.test.domain;

public class stationVO {
	
	private String station_num;
	private float Station_latitude;
	private float Station_longitude;
	private int Station_haveUm;
	private String Station_manager_id;
	
	public String getstation_num() {
		return station_num;
	}
	public void setstation_num(String num) {
		this.station_num = num ;
	}
	
	public float getStation_latitude() {
		return Station_latitude;
	}
	public void setStation_latitude(float latitude) {
		this.Station_latitude =  latitude;
	}
	
	public float getStation_longitude() {
		return Station_longitude;
	}
	public void setStation_longitude(float longitude) {
		this.Station_longitude =  longitude;
	}
	
	public int getStation_haveUm() {
		return Station_haveUm;
	}
	public void setStation_haveUm(int haveUm) {
		this.Station_haveUm =  haveUm;
	}
	public String getStation_manager_id() {
		return Station_manager_id;
	}
	public void setStation_manager_id(String manager_id) {
		this.Station_manager_id =  manager_id;
	}
	
}
