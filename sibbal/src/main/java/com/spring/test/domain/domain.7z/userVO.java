package com.spring.test.domain;

import java.util.Date;

public class userVO {
	private String user_id;
	private String user_name;
	private String user_pw;
	private String user_hp; //�� ��ȣ
	private Date user_birth;
	private String user_umCode;
	private Date user_rental;
	private int user_ap; //���� ����Ʈ
	private int user_lp; //�ܿ� ����Ʈ
	
	public String getuser_id() {
		return user_id;
	}
	public void setuser_id(String id) {
		this.user_id = id ;
	}
	public String getuser_name() {
		return user_name;
	}
	public void setuser_name(String name) {
		this.user_name = name;
	}
	public String getuser_pw() {
		return user_pw;
	}
	public void setuser_pw(String pw) {
		this.user_pw = pw;
	}
	public String getuser_hp() {
		return user_hp;
	}
	public void setuser_hp(String hp) {
		this.user_hp = hp;
	}
	public Date getuser_birth() {
		return user_birth;
	}
	public void setuser_birth(Date birth) {
		this.user_birth = birth;
	}
	public String getuser_umCode() {
		return user_umCode;
	}
	public void setuser_umCode(String umCode) {
		this.user_umCode = umCode;
	}
	public Date getuser_rental() {
		return user_rental;
	}
	public void setuser_rental(Date rental) {
		this.user_rental = rental;
	}
	public int getuser_ap() {
		return user_ap;
	}
	public void setuser_ap(int ap) {
		this.user_ap = ap;
	}
	public int getuser_lp() {
		return user_lp;
	}
	public void setuser_lp(int lp) {
		this.user_lp = lp;
	}
	
}